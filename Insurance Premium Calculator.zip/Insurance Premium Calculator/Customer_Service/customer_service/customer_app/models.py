from django.db import models

class Customer(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    smoker = models.BooleanField()
    has_illness = models.BooleanField()
    region = models.CharField(max_length=100)

    