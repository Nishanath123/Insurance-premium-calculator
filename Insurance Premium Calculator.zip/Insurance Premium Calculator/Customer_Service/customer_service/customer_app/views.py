from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import jwt
from .models import Customer

def validate_jwt(request):
    token = request.headers.get('Authorization')
    if not token:
        return Response({'detail': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
    try:
        jwt.decode(token.replace('Bearer ', ''), 'secret', algorithms=['HS256'])
    except:
        return Response({'detail': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)
    return None

@api_view(['POST'])
def add_customer(request):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    name = request.data.get('name')
    age = request.data.get('age')
    smoker = request.data.get('smoker')
    has_illness = request.data.get('has_illness')
    region = request.data.get('region')
    errors = {}
    if name is None:
        errors['name'] = ['This field is required.']
    if age is None:
        errors['age'] = ['This field is required.']
    if smoker is None:
        errors['smoker'] = ['This field is required.']
    if has_illness is None:
        errors['has_illness'] = ['This field is required.']
    if region is None:
        errors['region'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        age = int(age)
    except ValueError:
        return Response({'age': ['Invalid value.']}, status=status.HTTP_400_BAD_REQUEST)
    # if type(smoker) != bool or type(has_illness) != bool:
    #     return Response({'detail': 'Smoker and has_illness must be boolean.'}, status=status.HTTP_400_BAD_REQUEST)
    customer = Customer.objects.create(name=name, age=age, smoker=smoker, has_illness=has_illness, region=region)
    return Response({'id': customer.id, 'name': customer.name, 'age': customer.age, 'smoker': customer.smoker, 'has_illness': customer.has_illness, 'region': customer.region}, status=status.HTTP_201_CREATED)

@api_view(['GET'])
def get_customer(request, customer_id):
    try:
        customer = Customer.objects.get(id=customer_id)
        return Response({'id': customer.id, 'name': customer.name, 'age': customer.age, 'smoker': customer.smoker, 'has_illness': customer.has_illness, 'region': customer.region})
    except Customer.DoesNotExist:
        return Response({'detail': 'Not found'}, status=status.HTTP_404_NOT_FOUND)