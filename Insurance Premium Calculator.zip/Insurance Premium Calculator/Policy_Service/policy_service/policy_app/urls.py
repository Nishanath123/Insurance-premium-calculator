from django.contrib import admin
from django.urls import path
from policy_app.views import add_policy, get_policy

urlpatterns = [
    
    path('policies/', add_policy),
    path('policies/<int:policy_id>/', get_policy),
]