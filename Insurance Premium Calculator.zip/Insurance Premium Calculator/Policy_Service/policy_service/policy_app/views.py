from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import jwt
from .models import Policy

def validate_jwt(request):
    token = request.headers.get('Authorization')
    if not token:
        return Response({'detail': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
    try:
        jwt.decode(token.replace('Bearer ', ''), 'secret', algorithms=['HS256'])
    except:
        return Response({'detail': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)
    return None

@api_view(['POST'])
def add_policy(request):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    name = request.data.get('name')
    base_premium = request.data.get('base_premium')
    errors = {}
    if name is None:
        errors['name'] = ['This field is required.']
    if base_premium is None:
        errors['base_premium'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        base_premium = float(base_premium)
    except ValueError:
        return Response({'base_premium': ['Invalid value.']}, status=status.HTTP_400_BAD_REQUEST)
    policy = Policy.objects.create(name=name, base_premium=base_premium)
    return Response({'id': policy.id, 'name': policy.name, 'base_premium': str(policy.base_premium)}, status=status.HTTP_201_CREATED)

@api_view(['GET'])
def get_policy(request, policy_id):
    try:
        policy = Policy.objects.get(id=policy_id)
        return Response({'id': policy.id, 'name': policy.name, 'base_premium': str(policy.base_premium)})
    except Policy.DoesNotExist:
        return Response({'detail': 'Not found'}, status=status.HTTP_404_NOT_FOUND)