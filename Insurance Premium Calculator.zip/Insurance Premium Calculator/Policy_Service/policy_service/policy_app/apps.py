from django.apps import AppConfig


class PolicyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'policy_app'
