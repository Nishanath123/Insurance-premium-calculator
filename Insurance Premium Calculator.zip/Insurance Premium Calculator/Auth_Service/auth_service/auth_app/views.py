from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
import jwt
import re

@api_view(['POST'])
@csrf_exempt
def register_view(request):
    # Extract data with fallback to None
    username = request.data.get('username')
    password = request.data.get('password')
    email = request.data.get('email')

    # Validation
    errors = {}
    if not username or not isinstance(username, str) or len(username.strip()) == 0:
        errors['username'] = ['Username is required and cannot be empty.']
    elif User.objects.filter(username=username).exists():
        errors['username'] = ['This username is already taken.']
    elif not re.match(r'^[a-zA-Z0-9_]+$', username):
        errors['username'] = ['Username can only contain letters, numbers, and underscores.']

    if not password or not isinstance(password, str) or len(password) < 8:
        errors['password'] = ['Password is required and must be at least 8 characters long.']

    if email and not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        errors['email'] = ['Invalid email format.']

    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)

    # Create user
    try:
        user = User.objects.create_user(username=username, password=password, email=email)
        login(request, user)  # Optional: logs user in after registration
        token = jwt.encode({'user_id': user.id, 'username': user.username}, 'secret', algorithm='HS256')
        return Response({
            'token': token,
            'message': 'Registration successful',
            'user_id': user.id
        }, status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({'error': 'Registration failed due to an internal error.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@csrf_exempt
def login_view(request):
    # Extract data with fallback to None
    username = request.data.get('username')
    password = request.data.get('password')

    # Validation
    errors = {}
    if not username or not isinstance(username, str) or len(username.strip()) == 0:
        errors['username'] = ['Username is required and cannot be empty.']
    if not password or not isinstance(password, str):
        errors['password'] = ['Password is required.']

    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)

    # Authenticate user
    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({'error': 'Invalid username or password.'}, status=status.HTTP_401_UNAUTHORIZED)

    # Generate JWT token
    try:
        token = jwt.encode({'user_id': user.id, 'username': user.username}, 'secret', algorithm='HS256')
        return Response({
            'token': token,
            'message': 'Login successful',
            'user_id': user.id
        }, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'error': 'Failed to generate token.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)