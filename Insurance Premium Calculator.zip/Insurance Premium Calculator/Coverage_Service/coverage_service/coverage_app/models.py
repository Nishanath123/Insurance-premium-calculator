from django.db import models

class Coverage(models.Model):
    name = models.CharField(max_length=100)
    cost = models.DecimalField(max_digits=10, decimal_places=2)

class CustomerCoverage(models.Model):
    customer_id = models.IntegerField()
    coverage = models.ForeignKey(Coverage, on_delete=models.CASCADE)