from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import jwt
from .models import Coverage, CustomerCoverage

def validate_jwt(request):
    token = request.headers.get('Authorization')
    if not token:
        return Response({'detail': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
    try:
        jwt.decode(token.replace('Bearer ', ''), 'secret', algorithms=['HS256'])
    except:
        return Response({'detail': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)
    return None

@api_view(['POST'])
def add_coverage(request):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    name = request.data.get('name')
    cost = request.data.get('cost')
    errors = {}
    if name is None:
        errors['name'] = ['This field is required.']
    if cost is None:
        errors['cost'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        cost = float(cost)
    except ValueError:
        return Response({'cost': ['Invalid value.']}, status=status.HTTP_400_BAD_REQUEST)
    coverage = Coverage.objects.create(name=name, cost=cost)
    return Response({'id': coverage.id, 'name': coverage.name, 'cost': str(coverage.cost)}, status=status.HTTP_201_CREATED)

@api_view(['GET'])
def get_coverage(request, coverage_id):
    try:
        coverage = Coverage.objects.get(id=coverage_id)
        return Response({'id': coverage.id, 'name': coverage.name, 'cost': str(coverage.cost)})
    except Coverage.DoesNotExist:
        return Response({'detail': 'Not found'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
def get_customer_coverages(request, customer_id):
    ccs = CustomerCoverage.objects.filter(customer_id=customer_id)
    coverages = [{'id': cc.coverage.id, 'name': cc.coverage.name, 'cost': str(cc.coverage.cost)} for cc in ccs]
    return Response(coverages)

@api_view(['POST'])
def add_customer_coverage(request, customer_id):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    coverage_id = request.data.get('coverage_id')
    errors = {}
    if coverage_id is None:
        errors['coverage_id'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        coverage_id = int(coverage_id)
        coverage = Coverage.objects.get(id=coverage_id)
    except ValueError:
        return Response({'coverage_id': ['Invalid value.']}, status=status.HTTP_400_BAD_REQUEST)
    except Coverage.DoesNotExist:
        return Response({'detail': 'Coverage not found'}, status=status.HTTP_404_NOT_FOUND)
    CustomerCoverage.objects.create(customer_id=customer_id, coverage=coverage)
    return Response({'status': 'added'}, status=status.HTTP_201_CREATED)