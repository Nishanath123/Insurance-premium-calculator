from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import jwt
from .models import Region

def validate_jwt(request):
    token = request.headers.get('Authorization')
    if not token:
        return Response({'detail': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
    try:
        jwt.decode(token.replace('Bearer ', ''), 'secret', algorithms=['HS256'])
    except:
        return Response({'detail': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)
    return None

@api_view(['POST'])
def add_region(request):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    name = request.data.get('name')
    multiplier = request.data.get('multiplier')
    errors = {}
    if name is None:
        errors['name'] = ['This field is required.']
    if multiplier is None:
        errors['multiplier'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        multiplier = float(multiplier)
    except ValueError:
        return Response({'multiplier': ['Invalid value.']}, status=status.HTTP_400_BAD_REQUEST)
    region, created = Region.objects.get_or_create(name=name, defaults={'multiplier': multiplier})
    if not created:
        return Response({'detail': 'Region already exists'}, status=status.HTTP_400_BAD_REQUEST)
    return Response({'name': region.name, 'multiplier': str(region.multiplier)}, status=status.HTTP_201_CREATED)

@api_view(['GET'])
def get_region(request, region_name):
    try:
        region = Region.objects.get(name=region_name)
        return Response({'name': region.name, 'multiplier': str(region.multiplier)})
    except Region.DoesNotExist:
        return Response({'detail': 'Not found'}, status=status.HTTP_404_NOT_FOUND)