from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import jwt
import requests

def validate_jwt(request):
    token = request.headers.get('Authorization')
    if not token:
        return Response({'detail': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
    try:
        jwt.decode(token.replace('Bearer ', ''), 'secret', algorithms=['HS256'])
    except:
        return Response({'detail': 'Invalid token'}, status=status.HTTP_401_UNAUTHORIZED)
    return None

@api_view(['POST'])
def calculate_premium(request):
    auth_error = validate_jwt(request)
    if auth_error:
        return auth_error
    customer_id = request.data.get('customer_id')
    policy_id = request.data.get('policy_id')
    errors = {}
    if customer_id is None:
        errors['customer_id'] = ['This field is required.']
    if policy_id is None:
        errors['policy_id'] = ['This field is required.']
    if errors:
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)
    try:
        customer_id = int(customer_id)
        policy_id = int(policy_id)
    except ValueError:
        return Response({'detail': 'Invalid IDs.'}, status=status.HTTP_400_BAD_REQUEST)
    
    # Call Policy Service
    policy_resp = requests.get(f'http://localhost:8001/policies/{policy_id}/')
    if policy_resp.status_code != 200:
        return Response({'detail': 'Policy not found'}, status=status.HTTP_404_NOT_FOUND)
    policy_data = policy_resp.json()
    base_premium = float(policy_data['base_premium'])
    
    # Call Customer Service
    customer_resp = requests.get(f'http://localhost:8002/customers/{customer_id}/')
    if customer_resp.status_code != 200:
        return Response({'detail': 'Customer not found'}, status=status.HTTP_404_NOT_FOUND)
    customer_data = customer_resp.json()
    age = customer_data['age']
    smoker = customer_data['smoker']
    has_illness = customer_data['has_illness']
    region = customer_data['region']
    
    # Call Coverage Service
    coverages_resp = requests.get(f'http://localhost:8003/customers/{customer_id}/coverages/')
    if coverages_resp.status_code != 200:
        return Response({'detail': 'Coverages error'}, status=coverages_resp.status_code)
    coverages = coverages_resp.json()
    add_ons = sum(float(c['cost']) for c in coverages)
    
    # Call Geo Service
    geo_resp = requests.get(f'http://localhost:8004/regions/{region}/')
    if geo_resp.status_code != 200:
        return Response({'detail': 'Region not found'}, status=status.HTTP_404_NOT_FOUND)
    geo_data = geo_resp.json()
    multiplier = float(geo_data['multiplier'])
    
    # Calculate
    age_factor = 1.0 if age < 30 else 1.2 if age < 50 else 1.5
    risk_factor = 1.0 + (0.1 if smoker else 0) + (0.2 if has_illness else 0)
    adjusted_base = base_premium * age_factor * risk_factor * multiplier
    final_premium = adjusted_base + add_ons
    
    breakdown = {
        'base_premium': base_premium,
        'age_factor': age_factor,
        'risk_factor': risk_factor,
        'add_ons': add_ons,
        'region_factor': multiplier,
        'final_premium': final_premium
    }
    return Response(breakdown)